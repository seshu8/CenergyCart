package cartValidation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CenergyCartValidation {
	
	WebDriver driver;
	
	@BeforeTest
	
	public void beforeTest() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");//To disable browser notifications
		options.addArguments("--incognito");//Opening Chrome browser in incognito mode
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");// Setting up Chrome driver path.          
		driver = new ChromeDriver(options); 
		driver.manage().window().maximize();
		driver.get("https://www.powerbuy.co.th/th"); //Opening Site URL
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
  @Test
  public void AddToCart() throws InterruptedException {
	  //Search by using Keyword "TV"
	  driver.findElement(By.id("txt-searchBox-input")).sendKeys("TV");
	  driver.findElement(By.id("btn-searchBox-input")).click();
	  //Filter TV with "44 - 55 inches" screen size
	  driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[3]/div[2]/div/div[2]/div[1]/div/div/div/div/div[30]/div[2]/div/div/div[1]/div[1]/div")).click();
	  Thread.sleep(5000);
	  //Select 'SHARP TV UHD LED (55", 4K, Smart) 4T-C55CJ2X' TV from filter results
	  String product1 = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[3]/div[2]/div/div[2]/div[3]/div[3]/div[6]/div/div/div[3]/h3")).getText();
	  System.out.println(product1);
	  driver.findElement(By.id("lnk-viewProduct-264098-name")).click();
	  //Added product to the cart from details page
	  driver.findElement(By.id("btn-addCart-264098")).click();
	  driver.navigate().back();		
	  //Filter uncheck with "44 - 55 inches"
	  driver.findElement(By.xpath("//div[@class='Checkbox-dODbyV cdvmkr']")).click();
	  //Filter TV with "32 - 43 inches" screen size
	  driver.findElement(By.xpath("(//div[contains(@data-testid,'btn-checkbox')])[97]")).click();
	  Thread.sleep(5000);
	  //Select 'SAMSUNG TV FHD QLED (32", Smart) QA32LS03TBKXXT' TV from filter results
	  String product2 = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[3]/div[2]/div/div[2]/div[3]/div[3]/div[1]/div/div/div[3]/h3")).getText();
	  System.out.println(product2);
	  driver.findElement(By.id("txt-productName-262249")).click();
	  //Added product to the cart from details page
	  driver.findElement(By.id("btn-addCart-262249")).click();
	  //Goto Cart Page
	  driver.findElement(By.id("btn-openMiniCart")).click();
	  Thread.sleep(5000);
	  //Get the cart values 
	  String cart1 = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[3]/div[2]/div[3]/div/div[1]/div[2]/div[1]/div/div[1]/div/div[2]/div[1]")).getText();
	  System.out.println(cart1);
	  String cart2 = driver.findElement(By.xpath("//div[@class='MultipleLineClamp__ProductCutoffDot-jCGKBO fMOIos'][contains(.,'SAMSUNGทีวี FHD QLED (32\", Smart) รุ่น QA32LS03TBKXXT')]")).getText();
	  System.out.println(cart2);
	  //Validate result of items in the cart match with the items that added in the previous steps or not 
	  //Assert.assertEquals(product1, cart1); 
	  //Assert.assertEquals(product2, cart2); 
	  
  }
  
  @AfterTest
  public void aftertest() {
	  
  }
}
