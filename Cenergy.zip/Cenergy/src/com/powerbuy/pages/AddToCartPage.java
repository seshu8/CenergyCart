package com.powerbuy.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import seleniumimplementation.Seleniumimplementation;

public class AddToCartPage {
	//Search by using Keyword “TV”
	@FindBy(id="txt-searchBox-input")
	WebElement selectSearch;
	@FindBy(id="txt-searchBox-input")
	WebElement sendKeys;
	@FindBy(id="btn-searchBox-input")
	WebElement searchClick;
	//Filter TV with “44 - 55 inches” screen size
	@FindBy(xpath = "/html/body/div[2]/div/div[2]/div[3]/div[2]/div/div[2]/div[1]/div/div/div/div/div[30]/div[2]/div/div/div[1]/div[1]/div")
	WebElement selectFilter1;
	//Select 'SHARP TV UHD LED (55", 4K, Smart) 4T-C55CJ2X' TV from filter results
	@FindBy(id="lnk-viewProduct-264098-name")
	WebElement selectproduct1;
	//Added product to the cart from details page
	@FindBy(id="btn-addCart-264098")
	WebElement btnCheckout1;
	//Filter uncheck with “44 - 55 inches”
	@FindBy(xpath = "//div[@class='Checkbox-dODbyV cdvmkr']")
	WebElement uncheckFilter;
	//Filter TV with “32 - 43 inches” screen size
	@FindBy(xpath="/html/body/div[2]/div/div[2]/div[3]/div[2]/div/div[2]/div[1]/div/div/div/div/div[30]/div[2]/div/div/div[2]/div[1]/div")
	WebElement selectFilter2;
	//Select 'SAMSUNG TV FHD QLED (32", Smart) QA32LS03TBKXXT' TV from filter results
	@FindBy(id="txt-productName-262249")
	WebElement selectproduct2;
	//Added product to the cart from details page
	@FindBy(id="btn-addCart-262249")
	WebElement btnCheckout2;
	//Goto Cart Page
	@FindBy(xpath = "(//img[@src='/assets/8e371483.svg'])[1]")
	WebElement cartClick;
	//Get the Mini Cart Value
	@FindBy(xpath = "(//span[@class='Text-sc-9p67zt-0 byElXE'])[1]")
	WebElement getText;
	
	
	Seleniumimplementation selenium;
	
	public AddToCartPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		selenium = new Seleniumimplementation();
		
			}
	public boolean validateAddToCart(WebDriver driver) throws InterruptedException {
	
		selenium.click(selectSearch);
		selenium.setText("TV", sendKeys);
		selenium.click(searchClick);
		selenium.click(selectFilter1);
		Thread.sleep(5000);
		selenium.click(selectproduct1);
		selenium.click(btnCheckout1);
		selenium.back(driver);
		selenium.click(uncheckFilter);
		selenium.click(selectFilter2);
		Thread.sleep(5000);
		selenium.click(selectproduct2);
		selenium.click(btnCheckout2);
		Thread.sleep(5000);
		selenium.click(cartClick);
		selenium.refresh(driver);
		Thread.sleep(10000);
		selenium.click(getText);
							
		return selenium.validateText(driver, getText, "4");
		
	}

}
