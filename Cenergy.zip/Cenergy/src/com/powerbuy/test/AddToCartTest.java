package com.powerbuy.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.powerbuy.pages.AddToCartPage;

public class AddToCartTest {
	WebDriver driver;
	AddToCartPage page;
	
	@BeforeTest
	public void setup() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");//To disable browser notifications
		options.addArguments("--incognito");//Opening Chrome browser in incognito mode
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");// Setting up Chrome driver path.   
		driver = new ChromeDriver(options); 
		driver.manage().window().maximize();
		driver.get("https://www.powerbuy.co.th/th");//Opening Site URL
		page=new AddToCartPage(driver);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
		
  @Test
  public void validateAddToCart() throws InterruptedException {
	  //Validating the 'AddToCartPage' functionality
	  Assert.assertTrue(page.validateAddToCart(driver));
  }
}
