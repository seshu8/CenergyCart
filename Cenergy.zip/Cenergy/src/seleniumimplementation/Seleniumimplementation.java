package seleniumimplementation;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Seleniumimplementation {
	
	Actions action;
	
	public void setText(String text,WebElement element) {
		element.sendKeys(text);
	}
	public void click(WebElement element) {
		element.click();
	}
	
	public void back(WebDriver driver) {
		driver.navigate().back();
	}
	
	public void getText(WebDriver driver) {
		driver.getTitle();
	}
	
	public void cilckUsingJavaScriptExecutor(WebElement element, WebDriver driver) {
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void refresh(WebDriver driver) {
		Actions actionObject = new Actions(driver);
		actionObject.keyDown(Keys.CONTROL).sendKeys(Keys.F5).keyUp(Keys.CONTROL).perform();
		}

		public boolean validateText(WebDriver driver, WebElement element, String expectedText) {
	
	String observedText = element.getText();
	System.out.println(observedText);
	if (observedText.equals(expectedText)) {
		return true;					
	}
	return false;
		}

}
